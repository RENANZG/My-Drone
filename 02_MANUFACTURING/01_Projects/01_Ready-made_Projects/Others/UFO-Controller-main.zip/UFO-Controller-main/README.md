# UFO-Controller

When Summer 2022 started, some friends and I decided it would be cool to build our own quadcopter drones.
Eventually, we'd like to hook up FPV cameras, GPS units, and some other fun gizmos so that we can do cool stuff like FPV racing, autonomous path following with GPS, and smart object detection and wayfinding using computer vision.
Unfortunately we decided to build everything from scratch, and we all work full time and go to school, so progress is verrryyy slow :smiley:.
We appreaciate any and all help, and once we get in the air we will make sure to include writeups so others can learn from our mistakes!

Much of the transmitter code is extended from [akarsh98](https://github.com/akarsh98) on GitHub and [this guide on PPM via Arduino](https://quadmeup.com/generate-ppm-signal-with-arduino/). Thanks akarsh and Pawel!

## Project Overview

This repo contains wiring diagrams and PCB designs for physically constructing a quadcopter drone, as well as the code that runs the various components.
For an architectural overview, check out the most recent diagram on [Figma](https://www.figma.com/file/jF0iwjzia1yDUecFlRwKRH/Quadcopter-Architectural-Diagram?node-id=0%3A1&t=NQsfecrH3ePvGlxZ-1) or the printout in ```Diagrams/Architecture.png```.
Below are explanations on each of the sub-folders and what they are for, and you can find a README in each folder with more details:

Folder | Description
---|---|
```Arduino-ISP```     | Copied from Arduino IDE built-in example 11. Allows an Uno to program a Nano over ISP
```Wiring-Diagrams``` | PCB designs and board pinouts for transceiver, flight controller, etc for KiCad 6.0. Includes KiCad files for MPU breakout board.
```Hardware-Tests```  | Various programs for verifying that individual electronic components are working
```MultiWii```        | Flight control software from [MultiWii.com](http://www.multiwii.com/)
```MultiWiiConf```    | Configuration GUI for ```MultiWii```
```Transceiver```     | Instructions for using pair of Arduino as radio transmitter to drone

[Here is a list](https://docs.google.com/spreadsheets/d/10AE-gxLpqU5vgeOIUJY-S-56ZoEb90_Z4nvbcpwbEK8/edit?usp=sharing) of parts that I am using as well as links to buy them.
I bought generic versions of everything but you can find authentic versions by searching online.
They will cost more but work much reliably, and also potentially this will fix the hardware issue between Arduino Nano and nRF24 (see #12).

## Configuring VS Code IDE

If you are like me, you really hate the default Arduino IDE and you would rather use VS Code.
To do this:

1. Install the [Arduino VS Code extension](https://marketplace.visualstudio.com/items?itemName=vsciot-vscode.vscode-arduino)
2. Choose AVR programmer and Arduino Nano board
3. In ```c_cpp_properties.json```, update ```compilerPath```, ```includePath```, and ```forcedInclude``` so your machine's section matches that of the Arduino (basically tell intellisense to use the Arduino's compiler)
4. Add ```USBCON``` to ```defines``` in ```c_cpp_properties.json```
5. If you need 3rd-party libraries, put them in ```src``` in the root of this repo and symlink ```src``` in your code root folder to it (Arduino compiler should recognize the ```src``` folder automatically)

## Miscellaneous Resources That Will Be Added Into The Docs Later

- https://create.arduino.cc/projecthub/akarsh98/diy-arduino-based-quadcopter-drone-948153
- https://www.hackster.io/robocircuits/arduino-quadcopter-e618c6
- https://howtomechatronics.com/projects/diy-arduino-rc-transmitter/
- https://www.modelflight.com.au/blog/a-guide-to-understanding-lipo-batteries
- https://www.instructables.com/DJi-F450-Quadcopter-How-to-Build-Home-Built/
- http://www.rctutor.org/the-parts-list.html
- [Read-only Amazon link for parts](https://www.amazon.com/hz/wishlist/ls/1BKLT1DHMK0VX?ref_=wl_share)
- [PPM communication via Arduino](https://quadmeup.com/generate-ppm-signal-with-arduino/)
