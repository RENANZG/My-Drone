# Hardware-Tests/PPMReader

This program reads a PPM signal, and can help verify that ```Transceiver``` is sending a PPM signal correctly. This basically takes the place of the MultiWii controller. To use, simply upload to another Arduino and connect the grounds together and pin 2 to the PPM output from the ```Transceiver``` receiving Arduino.
