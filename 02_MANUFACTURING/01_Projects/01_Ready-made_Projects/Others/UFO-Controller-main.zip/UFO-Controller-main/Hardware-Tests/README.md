# Hardware-Tests

These are some basic programs for testing that various components of the drone are working.
I highly recommend you verify all of your hardware is working correctly BEFORE trying everything together, since there is nothing worse than spending hours on a "software" bug that doesn't actually exist.
Plus if you're like me you bought the cheapest stuff you could find and there's a good chance it won't all work right :smiley:.

Each test should have a README on how to use the code to verify the hardware, but some of the simpler ones just have comments in the code explaining how it works.
If you get stuck then submit an Issue so I can update the docs.
