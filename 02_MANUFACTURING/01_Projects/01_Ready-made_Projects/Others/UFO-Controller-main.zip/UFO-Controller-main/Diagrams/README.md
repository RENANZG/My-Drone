# Diagrams

```Pinouts``` contains chip pinout diagrams for Arduino Uno and Nano, gyroscope, and radio.
These are just taken from online, they are here as quick reference.

```UFO-PCB``` is the actual PCB model that goes on the drone.
Download KiCad here: [kicad.org](https://www.kicad.org/).

The source for ```Architecture.png``` is on [Figma](https://www.figma.com/file/jF0iwjzia1yDUecFlRwKRH/Quadcopter-Architectural-Diagram?node-id=0%3A1&t=NQsfecrH3ePvGlxZ-1).
