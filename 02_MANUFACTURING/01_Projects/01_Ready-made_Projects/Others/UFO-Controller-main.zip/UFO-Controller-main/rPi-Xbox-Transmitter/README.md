# TXbox: Raspberry Pi Xbox Transmitter

This program uses an Xbox controller connected over USB to a Raspberry Pi to talk to the Arduino receiver in ```/Transceiver```.

It uses this library [bjarne-hansen/py-nrf24](https://github.com/bjarne-hansen/py-nrf24).

## Deployment

To deploy to a Pi... TODO add setup instructions
